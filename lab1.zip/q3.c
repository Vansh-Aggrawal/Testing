#include <stdio.h>
#include <stdlib.h>
#include <math.h>

int comb(int try, int *l, int n, int s)
{
    int *arr = calloc(n, sizeof(int));
    int dec = try;
    int i = 0;
    int tot = 0;

    if (dec >= 0)
    {
        while (dec > 0)
        {
            arr[i] = dec % 2;
            i++;
            dec = dec / 2;
        }
    }
    for (int i = 0; i < n; i++)
    {
        tot += arr[i] * l[i];
    }

    if (tot == s)
    {
        for (int i = 0; i < n; i++)
        {
            if (arr[i] == 1)
                printf("%d ", i);
        }
        free(arr);
        printf("jj");
        return 1;
    }
    else
    {
        // printf("%d\n", try);
        free(arr);

        return 0;
    }
}

int main()
{
    int n;
    int *l = malloc(sizeof(int) * n);
    int tot;
    int found = 0;
    // int found=0;

    scanf("%d", &n);
    for (int i = 0; i < n; i++)
    {
        scanf("%d", &l[i]);
    }
    scanf("%d", &tot);

    // int comb = calloc(n, sizeof(int));
    for (int i = 0; i < pow(2, n); i++)
    {
        if (comb(i, l, n, tot))
        {
            found = 1;
            i = pow(2, n) + 1;
        }
    }

    // printf("ll");

    if (found == 0)
        printf("NOT FOUND");

    return 0;
}