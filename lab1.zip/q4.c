#include <stdio.h>
#include <stdlib.h>

int main()
{
    int n;
    scanf("%d", &n);
    int *l = (int *)malloc(sizeof(int) * n);

    for (int i = 0; i < n; i++)
    {
        int df = 0;
        scanf("%d ", &df);
        l[i] = df;
    }
    for (int i = 0; i < n - 1; i++)
    {
        for (int j = 0; j < n - 1; j++)
        {
            if ((l[j] >= 0) && (l[j + 1] <= 0))
            {
                int temp;
                temp = l[j];
                l[j] = l[j + 1];
                l[j + 1] = temp;
            }
        }
    }

    for (int i = 0; i < n; i++)
        printf("%d ", l[i]);

    free(l);
    return 0;
}