#include <stdio.h>
#include <math.h>

int checkprime(int n)
{
    int ans = 1;
    for (int i = 2; i < n / 2; i++)
    {
        if (n % i == 0)
        {
            // printf("%d %d\n", n, i);
            ans = 0;
            break;
        }
    }
    return ans;
}
int main()
{
    int a, b;
    scanf("%d %d", &a, &b);
    int l[] = {0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
    for (int i = a; i < b + 1; i++)
    {
        if (checkprime(i))
        {
            // printf("hi");
            int temp = i;
            while (temp > 0)
            {
                l[temp % 10]++;
                temp = (int)temp / 10;
            }
        }
    }
    int max = 0;
    for (int i = 0; i < 10; i++)
    {
        // printf("%d  ", l[i]);
        if (l[i] > l[max])
        {
            max = i;
        }
    }
    printf("%d %d", max, l[max]);
}