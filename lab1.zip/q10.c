#include <stdio.h>
#include <stdlib.h>
#include <string.h>
int main()
{

    char a[30], b[30];
    scanf("%[^\n]%*c", a);
    scanf("%[^\n]%*c", b);

    int al = strlen(a), bl = strlen(b);
    int flag = 1;
    int *ans = (int *)malloc(al * sizeof(int));
    if (al != bl)
    {
        printf("NOT POSSIBLE");
        return 0;
    }
    for (int i = 0; i < bl; i++)
    {
        char *si = strchr(a, b[i]);
        if (si != NULL)
        {
            printf("%d ", si - a + 1);
            *si = '\1';
        }
        else
        {
            flag = 0;
            break;
        }
    }
    if (!flag)
    {
        printf("NOT POSSIBLE");
    }
    free(ans);
    return 0;
}