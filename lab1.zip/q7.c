#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int main()
{
    char *s = malloc(sizeof(char) * 100);
    char *s2 = malloc(sizeof(char) * 100);
    char bu;
    scanf("%[^\n]s", s);

    scanf("%c %[^\n]s", &bu, s2);
    char *temp = malloc(sizeof(char) * 100);

    int l2 = strlen(s2);
    int l = strlen(s);

    int flagL = 0, flagR = 0;
    int ansl = 0, ansr = l;
    int f = 0;
    for (int i = 0; i < l - l2 + 1; i++)
    {
        int found = 0;
        strcpy(temp, s);
        // printf("%s", temp);
        flagL = i;
        for (int j = 0; j < l2; j++)
        {
            char *ch = strchr(temp + i, s2[j]);
            if (ch != NULL)
            {
                found++;
                if (flagR < ch - temp)
                {
                    flagR = ch - temp;
                }
                *ch = ' ';
                // printf("%s %d\n", temp, ch);
            }
            else
            {
                continue;
            }
        }
        if ((ansr - ansl) > (flagR - flagL) && found == l2)
        {
            f = 1;
            ansl = flagL;
            ansr = flagR;
        }
        // printf("%d %d %d>%d\n", ansl, ansr, ansr - ansl, flagR - flagL);
    }
    if (f == 1)
    {
        printf("%d  %d", ansl, ansr);
    }
    else
    {
        printf("NO WINDOW");
    }
    // for (int i = 0; i < l; i++)
    // {

    // }
    return 0;
}