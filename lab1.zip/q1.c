#include <stdio.h>
#include <stdlib.h>

int main()
{
    int m, n;
    scanf("%d%d", &m, &n);
    int **a = (int **)malloc(sizeof(int *) * m);
    for (int i = 0; i < m; i++)
    {
        a[i] = (int *)malloc(sizeof(int) * n);
    }
    for (int i = 0; i < m; i++)
    {
        for (int j = 0; j < n; j++)
        {
            scanf("%d", &(a[i][j]));
        }
    }

    int ri, ci, rh, ch;
    scanf("%d%d%d%d", &ri, &ci, &rh, &ch);
    int s = 0;
    for (int i = 0; i < m; i++)
    {
        for (int j = 0; j < n; j++)
        {
            s = s + a[i][j];
            a[i][j] = s;
        }
    }
    printf("\n");
    for (int i = 0; i < m; i++)
    {
        for (int j = 0; j < n; j++)
        {
            printf("%-4d ", a[i][j]);
        }
        printf("\n");
    }
    s = 0;
    if ((ri + rh) <= n && (ci + ch) <= m)
    {
        for (int i = ri; i < (ri + rh); i++)
        {
            for (int j = ci; j < (ci + ch); j++)
            {
                s = s + a[i][j];
            }
        }
        printf("\n%d", s);
    }
    else
    {
        printf("NOT POSSIBLE");
    }
    return 0;
    for (int i = 0; i < m; i++)
    {
        free(a[i]);
    }
    free(a);
}