#include <stdio.h>
#include <stdlib.h>

int ar, ac;
int br, bc;
int checkc(int *a, int *b)
{
    int ans = 1;
    for (int i = 0; i < br; i++)
    {
        if (*(a + i * ac) != *(b + i * bc))
        {
            ans = 0;
        }
    }
    return ans;
}
int checkr(int *a, int *b)
{
    int ans = 1;
    for (int i = 0; i < br; i++)
    {
        if (*(a + i) != *(b + i))
        {
            ans = 0;
        }
    }
    return ans;
}
int main()
{
    scanf("%d %d", &ar, &ac);
    int *a = (int *)malloc(sizeof(int *) * ar * ac);
    for (int i = 0; i < ar; i++)
    {
        for (int j = 0; j < ac; j++)
        {
            scanf("%d", &a[i * ac + j]);
        }
    }
    scanf("%d %d", &br, &bc);
    int *b = (int *)malloc(sizeof(int *) * br * bc);
    for (int i = 0; i < br; i++)
    {
        for (int j = 0; j < bc; j++)
        {
            scanf("%d", &b[i * bc + j]);
        }
    }
    int cflag = 0, rflag = 0, cflagtot = 0, rflagtot = 0;
    for (int i = 0; i < ar - br + 1; i++)
    {
        for (int j = 0; j < ac - bc + 1; j++)
        {
            int cr = checkr(a + i * ac + j, b);
            int cc = checkc(a + i * ac + j, b);
            rflagtot = rflagtot + cr;
            rflag = rflag + cr;
            cflag = cflag + cc;
            cflagtot = cflagtot + cc;
        }
        if (rflag == br - 1 && cflag == bc - 1)
            break;
        else
        {
            rflag = 0;
            cflag = 0;
        }
    }
    if (rflag == br - 1 && cflag == bc - 1)
        printf("YES");
    else if (cflagtot > 0 || rflagtot > 0)
        printf("PARTIAL");
    else
        printf("NO");
    return 0;
}