#include <stdio.h>
#include <stdlib.h>
#include <string.h>
int main()
{
    char *s = malloc(sizeof(char) * 100);
    char *s2 = malloc(sizeof(char) * 100);

    scanf("%[^\n]s", s);

    int i = 0, l = strlen(s), star = 0;
    s[l] = ' ';
    s[l + 1] = '\0';
    l = l + 1;
    strcpy(s2, s);
    while (i < l)
    {
        if (s[i] == ' ')
        {
            for (int j = star; j < ((i + star) / 2); j++)
            {
                char t = s[j];
                s[j] = s[i - 1 + star - j];
                s[i - 1 + star - j] = t;
            }
            star = i + 1;
        }
        i++;
    }
    printf("\n%s\n", s);
    star = 0;
    int palin = 0;
    for (int i = 0; i < l; i++)
    {

        if (s[i] == ' ')
        {
            // printf("hi");
            if (strncmp(s2 + star, s + star, i - star - 1) == 0 && (i - star) > 1)
            {
                palin++;
                for (int j = star; j < i; j++)
                {
                    printf("%c", s2[j]);
                }
                printf(" ");
            }
            star = i + 1;
        }
    }
    if (!palin)
    {
        printf("NO PALINDROMES");
    }

    return 0;
}