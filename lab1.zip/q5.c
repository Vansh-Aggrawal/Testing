#include <stdio.h>
#include <stdlib.h>

void changetype(int *type)
{
    (*type)++;
    if ((*type) == 5)
        *type = 1;
}
int main()
{
    printf("enter number:");
    int n;
    scanf("%d", &n);
    int **a = (int **)malloc(sizeof(int *) * n);
    for (int i = 0; i < n; i++)
    {
        a[i] = (int *)malloc(sizeof(int) * n);
    }
    int x, y = n / 2;
    if (n % 2 == 0)
        x = n / 2 - 1;
    else
        x = n / 2;
    int data = 2;
    a[y][x] = data;
    int type = 1, c = 1, t = 0; // 1-r  2-u  3-l  4-d
    while (data < (2 * n * n))
    { // 1223344556..
        data = data + 2;
        if (type == 1)
        {
            a[y][++x] = data;

            t++;
            if (t == c)
            {
                changetype(&type);
                t = 0;
            }
        }
        else if (type == 2)
        {
            a[--y][x] = data;
            t++;
            if (t == c)
            {
                changetype(&type);
                t = 0;
                c++;
            }
        }
        else if (type == 3)
        {
            a[y][--x] = data;
            t++;
            if (t == c)
            {
                changetype(&type);
                t = 0;
            }
        }
        else if (type == 4)
        {
            a[++y][x] = data;
            t++;
            if (t == c)
            {
                changetype(&type);
                t = 0;
                c++;
            }
        }
    }
    for (int i = 0; i < n; i++)
    {
        for (int j = 0; j < n; j++)
        {
            printf("%4d", a[i][j]);
            if (j < n - 1 && abs(a[i][j] - a[i][j + 1]) == 2)
            {
                printf(" ― ");
            }
            else
            {
                printf("   ");
            }
        }
        printf("\n");
        for (int j = 0; j < n; j++)
        {
            if (i < n - 1 && abs(a[i + 1][j] - a[i][j]) == 2)
                printf("   |   ");
            else
                printf("       ");
        }
        printf("\n");
    }
    return 0;
}