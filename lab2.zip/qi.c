#include <stdio.h>
#include <stdlib.h>
#include <string.h>
int main()
{
    char mail[38], branch[4];

    scanf("%[^\n]s", mail);
    getchar();
    scanf("%[^\n]s", branch);

    char ans[14];
    for (int i = 1; i < 5; i++)
        ans[i - 1] = mail[i];
    ans[4] = 'A';
    if (strcmp(branch, "CS") == 0)
    {
        ans[5] = '7';
    }
    if (strcmp(branch, "ECE") == 0)
    {
        ans[5] = 'A';
    }
    if (strcmp(branch, "EEE") == 0)
    {
        ans[5] = '3';
    }
    ans[6] = 'P';
    ans[7] = 'S';
    for (int i = 5; i < 9; i++)
        ans[i + 3] = mail[i];
    ans[12] = 'H';
    ans[13] = '\0';
    printf("%s\n", ans);
    // for (int i = 0; i < 13; i++)
    //     printf("%c", ans[i]);
    printf("\n");
    return 0;
}
