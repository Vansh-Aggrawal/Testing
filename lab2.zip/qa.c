#include <stdio.h>
#include <stdlib.h>

struct node
{
    int data;
    struct node *next;
};
typedef struct node Node;

Node *createnode(int d)
{
    Node *n = malloc(sizeof(Node));
    n->data = d;
    n->next = NULL;
    return n;
}

Node *addtolist(Node *head, int val)
{
    Node *n = createnode(val);
    if (head == NULL)
    {
        return n;
    }
    Node *cur = head;
    while (cur->next != NULL)
    {
        cur = cur->next;
    }
    cur->next = n;
    return head;
}

Node *readList()
{
    int n;
    scanf("%d", &n);
    Node *head = NULL;

    for (int i = 0; i < n; i++)
    {
        int val;
        scanf("%d", &val);
        head = addtolist(head, val);
    }
    return head;
}
void printList(Node *head)
{
    Node *cur = head;
    while (cur != NULL)
    {
        printf("%d\n", cur->data);
        cur = cur->next;
    }
}
void freeList(Node *head)
{
    Node *cur, *next;
    cur = head;
    while (cur != NULL)
    {
        next = cur->next;
        free(cur);
        cur = next;
    }
}
int findLen(Node *head)
{
    int n = 0;
    Node *node = head;
    while (node != NULL)
    {
        n++;
        node = node->next;
    }
    return n;
}
int findMedian(Node *head)
{
    int n = findLen(head);
    Node *cur = head;
    int med;
    if (n % 2 == 1)
    {
        for (int i = 0; i < (int)n / 2; i++)
        {
            cur = cur->next;
        }
        med = cur->data;
    }
    else
    {
        for (int i = 0; i < (int)n / 2 - 1; i++)
        {
            cur = cur->next;
        }
        med = cur->data;
        med = med + cur->next->data;
        med = (int)med / 2;
    }
    return med;
}
int main()
{
    Node *head = readList();
    // printList(head);
    printf("%d", findMedian(head));
    freeList(head);
    return 0;
}