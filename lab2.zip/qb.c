#include <stdio.h>
#include <stdlib.h>

struct node
{
    int data;
    struct node *next;
};
typedef struct node Node;

Node *createnode(int d)
{
    Node *n = malloc(sizeof(Node));
    n->data = d;
    n->next = NULL;
    return n;
}

Node *addtolist(Node *head, int val)
{
    Node *n = createnode(val);
    if (head == NULL)
    {
        return n;
    }
    Node *cur = head;
    while (cur->next != NULL)
    {
        cur = cur->next;
    }
    cur->next = n;
    return head;
}

Node *readList()
{
    int n;
    scanf("%d", &n);
    Node *head = NULL;

    for (int i = 0; i < n; i++)
    {
        int val;
        scanf("%d", &val);
        head = addtolist(head, val);
    }
    return head;
}
void printList(Node *head)
{
    Node *cur = head;
    while (cur != NULL)
    {
        printf("%d ", cur->data);
        cur = cur->next;
    }
    printf("\n");
}

void freeList(Node *head)
{
    Node *cur, *next;
    cur = head;
    while (cur != NULL)
    {
        next = cur->next;
        free(cur);
        cur = next;
    }
}
Node *mergeLists(Node *head1, Node *head2)
{
    Node *mhead = NULL, *cur1 = head1, *cur2 = head2;
    while (cur1 != NULL || cur2 != NULL)
    {

        if (cur1 == NULL || (cur2 != NULL && (cur1->data > cur2->data)))
        {
            int val;
            val = cur2->data;
            cur2 = cur2->next;
            mhead = addtolist(mhead, val);
        }
        else if (cur2 == NULL || (cur1 != NULL && (cur2->data >= cur1->data)))
        {
            int val;
            val = cur1->data;

            cur1 = cur1->next;
            mhead = addtolist(mhead, val);
        }
        // printf("%d  %d\n ", cur1->data, cur2->data);
    }
    return mhead;
}
int main()
{
    Node *head1 = readList();
    Node *head2 = readList();
    Node *merged = mergeLists(head1, head2);
    printList(merged);
    freeList(head1);
    freeList(head2);
    freeList(merged);
    return 0;
}