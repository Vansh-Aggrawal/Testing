#include <stdio.h>
#include <stdlib.h>

struct node
{
    int data;
    struct node *next;
};
typedef struct node Node;

Node *createnode(int d)
{
    Node *n = malloc(sizeof(Node));
    n->data = d;
    n->next = NULL;
    return n;
}

Node *addtolist(Node *head, int val)
{
    Node *n = createnode(val);
    if (head == NULL)
    {
        return n;
    }
    Node *cur = head;
    while (cur->next != NULL)
    {
        cur = cur->next;
    }
    cur->next = n;
    return head;
}

Node *readList()
{
    int n;
    scanf("%d", &n);
    Node *head = NULL;

    for (int i = 0; i < n; i++)
    {
        int val;
        scanf("%d", &val);
        head = addtolist(head, val);
    }
    return head;
}
int findlen(Node *head)
{
    int n = 0;
    Node *cur = head;
    while (cur != NULL)
    {
        n++;
        cur = cur->next;
    }
    return n;
}

void printList(Node *head)
{
    Node *cur = head;
    while (cur != NULL)
    {
        printf("%d ", cur->data);
        cur = cur->next;
    }
    printf("\n");
}

void freelist(Node *head)
{
    Node *cur = head, *next;
    while (cur != NULL)
    {
        next = cur->next;
        free(cur);
        cur = next;
    }
}
Node *getnode(Node *head, int n)
{
    Node *cur = head;
    int i = 0;
    while (cur != NULL && i < n)
    {
        cur = cur->next;
        i++;
    }
    return cur;
}
Node *removeNode(Node *head, int k)
{
    int n = k;
    if (n == 0)
    {
        return head->next;
    }
    else
    {
        Node *prev = getnode(head, n - 1);
        Node *cur = getnode(head, n);
        prev->next = cur->next;
        free(cur);
    }
    return head;
}

Node *removeRepeatedNodes(Node *head)
{
    int n = findlen(head);
    Node *cur = head->next;
    Node *prev = head;
    Node *next = cur->next;
    int i = 0;
    while (i < n)
    {
        int d = prev->data, f = 0;
        while (i < n && d == cur->data)
        {
            f = 1;
            if (i == 0)
            {
                head = removeNode(head, i);
                n--;
                free(prev);
                if (i < n)
                    prev = getnode(head, i);
            }
            else
            {
                head = removeNode(head, i);
                n--;
                if (i < n)
                    prev = getnode(head, i);
            }
            if (i < n - 1)
                cur = getnode(head, i + 1);
        }
        i++;
        if (f == 1)
        {
            n--;
            head = removeNode(head, i - 1);
        }
        prev = getnode(head, i);
        if (i < n - 1)
            cur = getnode(head, i + 1);
        else
        {
            break;
        }
    }
    return head;
}

int main()
{
    Node *head = readList();
    Node *newList = removeRepeatedNodes(head);
    printList(newList);

    freelist(head);
    // freelist(newList);

    return 0;
}