#include <stdio.h>
#include <stdlib.h>

struct node
{
    int data;
    struct node *next;
};
typedef struct node Node;

Node *createnode(int val)
{
    Node *n = malloc(sizeof(Node));
    n->data = val;
    n->next = NULL;
    return n;
}

Node *addtolist(Node *head, int val)
{
    Node *n = createnode(val);
    if (head == NULL)
    {
        return n;
    }
    Node *cur = head;
    while (cur->next != NULL)
    {
        cur = cur->next;
    }
    cur->next = n;
    return head;
}

Node *readList()
{
    int n;
    scanf("%d", &n);
    Node *head = NULL;
    for (int i = 0; i < n; i++)
    {
        int val;
        scanf("%d", &val);
        head = addtolist(head, val);
    }
    return head;
}

void printList(Node *head)
{
    Node *cur = head;
    while (cur != NULL)
    {
        printf("%d ", cur->data);
        cur = cur->next;
    }
    printf("\n");
}

void freeList(Node *head)
{
    Node *cur, *next;
    cur = head;
    while (cur != NULL)
    {
        next = cur->next;
        free(cur);
        cur = next;
    }
}
int findLen(Node *head)
{
    int n = 0;
    Node *node = head;
    while (node != NULL)
    {
        n++;
        node = node->next;
    }
    return n;
}
Node *getnode(Node *head, int n)
{
    Node *cur = head;
    int i = 0;
    while (cur != NULL && i < n)
    {
        cur = cur->next;
        i++;
    }
    return cur;
}
int isPalindrome(Node *head)
{
    int n = findLen(head);
    int ans = 1;
    Node *l, *r;
    for (int i = 0; i < (int)(n / 2); i++)
    {
        l = getnode(head, i);
        r = getnode(head, n - i - 1);
        if (l->data != r->data)
        {
            ans = 0;
        }
    }
    return ans;
}
int main()
{
    Node *head = readList();
    int palin = isPalindrome(head);
    printf("%d\n", palin);
    freeList(head);
    return 0;
}