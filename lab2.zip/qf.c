#include <stdio.h>
#include <stdlib.h>

struct node
{
    int data;
    struct node *next;
};
typedef struct node Node;

Node *createnode(int d)
{
    Node *n = malloc(sizeof(Node));
    n->data = d;
    n->next = NULL;
    return n;
}

Node *addtolist(Node *head, int val)
{
    Node *n = createnode(val);
    if (head == NULL)
    {
        return n;
    }
    Node *cur = head;
    while (cur->next != NULL)
    {
        cur = cur->next;
    }
    cur->next = n;
    return head;
}

Node *readList()
{
    int n;
    scanf("%d", &n);
    Node *head = NULL;

    for (int i = 0; i < n; i++)
    {
        int val;
        scanf("%d", &val);
        head = addtolist(head, val);
    }
    return head;
}

void printList(Node *head)
{
    Node *cur = head;
    while (cur != NULL)
    {
        printf("%d ", cur->data);
        cur = cur->next;
    }
}

void freelist(Node *head)
{
    Node *cur = head, *next;
    while (cur != NULL)
    {
        next = cur->next;
        free(cur);
        cur = next;
    }
}
Node *getnode(Node *head, int n)
{
    Node *cur = head;
    int i = 0;
    while (cur != NULL && i < n)
    {
        cur = cur->next;
        i++;
    }
    return cur;
}
int findlen(Node *head)
{
    int n = 0;
    Node *cur = head;
    while (cur != NULL)
    {
        n++;
        cur = cur->next;
    }
    return n;
}
//-1 4 2 -5 8 2 7 9
//-1 2 4 8 -5 7 2 9
//-1 2 8 4 7 -5 9 2
//-1 2 8 7 4 9 -5 2
//-1 2 8 7 4 -5 9 2
Node *swapadjacent(Node *head, int n)
{
    Node *tempn = getnode(head, n);
    Node *tempnp = getnode(head, n - 1);
    Node *next = getnode(head, n + 1);
    tempnp->next = next;
    tempn->next = next->next;
    next->next = tempn;
    return head;
}
Node *rearrangeList(Node *head)
{
    int n = findlen(head);
    for (int i = 1; i < n / 2 + n % 2; i++)
    {
        for (int j = i; j < n - 1; j = j + 2)
        {
            head = swapadjacent(head, j);
        }
    }
    for (int i = n / 2 + 1 + n % 2; i < n - 1; i++)
    {
        for (int j = i; j < n - 1; j = j + 2)
        {
            head = swapadjacent(head, j);
        }
    }
    return head;
}
int main()
{
    Node *head = readList();
    Node *newList = rearrangeList(head);
    // head = swapadjacent(head, 2);
    // printList(head);
    printList(newList);

    freelist(head);
    // freelist(newList);

    return 0;
}