#include <stdio.h>
#include <stdlib.h>

char **sort(int n, char **a, int *gold, int *silver, int *bronze)
{
    for (int j = 0; j < n - 1; j++)
    {
        for (int i = 0; i < n - 1; i++)
        {
            if (gold[i] < gold[i + 1])
            {
                char *tempa = *(a + i);
                int g = *(gold + i), s = *(silver + i), b = *(bronze + i);
                *(a + i) = *(a + i + 1);
                *(gold + i) = *(gold + i + 1);
                *(silver + i) = *(silver + i + 1);
                *(bronze + i) = *(bronze + i + 1);
                *(a + i + 1) = tempa;
                *(gold + i + 1) = g;
                *(silver + i + 1) = s;
                *(bronze + i + 1) = b;
            }
            else if (gold[i] == gold[i + 1] && silver[i] < silver[i + 1])
            {
                char *tempa = *(a + i);
                int g = *(gold + i), s = *(silver + i), b = *(bronze + i);
                *(a + i) = *(a + i + 1);
                *(gold + i) = *(gold + i + 1);
                *(silver + i) = *(silver + i + 1);
                *(bronze + i) = *(bronze + i + 1);
                *(a + i + 1) = tempa;
                *(gold + i + 1) = g;
                *(silver + i + 1) = s;
                *(bronze + i + 1) = b;
            }
            else if (silver[i] == silver[i + 1] && bronze[i] < bronze[i + 1])
            {
                char *tempa = *(a + i);
                int g = *(gold + i), s = *(silver + i), b = *(bronze + i);
                *(a + i) = *(a + i + 1);
                *(gold + i) = *(gold + i + 1);
                *(silver + i) = *(silver + i + 1);
                *(bronze + i) = *(bronze + i + 1);
                *(a + i + 1) = tempa;
                *(gold + i + 1) = g;
                *(silver + i + 1) = s;
                *(bronze + i + 1) = b;
            }
        }
    }
    return a;
}
int main()
{
    int n;
    scanf("%d", &n);
    char **a = (char **)malloc(sizeof(char *) * n);
    int *gold = (int *)malloc(sizeof(int) * n);
    int *silver = (int *)malloc(sizeof(int) * n);

    int *bronze = (int *)malloc(sizeof(int) * n);

    for (int i = 0; i < n; i++)
    {
        a[i] = (char *)malloc(sizeof(char) * 40);
    }
    // printf("%d \n", ' ');
    for (int i = 0; i < n; i++)
    {
        getchar();
        scanf("%s %d %d %d", a[i], &gold[i], &silver[i], &bronze[i]);
    }
    char **sorted = sort(n, a, gold, silver, bronze);
    for (int i = 0; i < n; i++)
    {
        printf("%s ", sorted[i]);
    }
    free(gold);
    free(silver);
    free(bronze);
    for (int i = 0; i < n; i++)
    {
        free(a[i]);
        free(sorted[i]);
    }
    free(a);
    free(sorted);
    return 0;
}