#include <stdio.h>
#include <stdlib.h>
#include <math.h>

int *makeseive(int n)
{
    int *s = calloc(n, sizeof(int));
    for (int i = 2; i * i < n + 1; i++)
    {
        if (s[i] == 0)
        {
            for (int j = i * i; j < n; j = j + i)
            {
                s[j] = 1;
            }
        }
    }
    return s;
}

void sum(int *s, int q, int n)
{
    for (int i = 1; i < n; i++)
    {
        s[i] = s[i] + s[i - 1];
    }
}

void countprime(int n, int *a, int q)
{
    int *s = makeseive(n);
    sum(s, q, n);
    for (int i = 0; i < q; i++)
    {
        printf("%d ",
               a[i] - s[a[i]] - 1);
    }
    printf("\n");
}

int main()
{
    int n, q;
    scanf("%d %d", &n, &q);
    int *l = malloc(sizeof(int) * q);
    for (int i = 0; i < q; i++)
        scanf("%d", &l[i]);

    countprime(n, l, q);
    return 0;
}