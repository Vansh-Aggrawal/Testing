#include <stdio.h>
#include <stdlib.h>

struct slot
{
    int st;
    int end;
};
typedef struct slot slot;

void merge(slot *slots, int l, int m, int r)
{
    int i, j, k;
    int n1 = m - l + 1;
    int n2 = r - m;

    slot *L, *R;
    L = malloc(sizeof(slot) * n1);
    R = malloc(sizeof(slot) * n2);
    for (int i = 0; i < n1; i++)
    {
        L[i] = slots[l + i];
    }
    for (int i = 0; i < n2; i++)
    {
        R[i] = slots[m + 1 + i];
    }
    i = 0;
    j = 0;
    k = l;
    // printf("n%d %dn\n", n1, n2);
    while (i < n1 || j < n2)
    {
        if ((L[i].st < R[j].st && i < n1) || j == n2)
        {
            // printf("d%dd\n", L[i].st);
            slots[k] = L[i];
            i++;
        }
        else if ((j < n2) || i == n1)
        {
            // printf("e%de\n", R[j]);
            slots[k] = R[j];
            j++;
        }
        else
        {
            break;
        }
        // printf("hu");
        k++;
    }
    free(L);
    free(R);
}
slot *sort(slot *slots, int l, int r)
{
    if (l < r)
    {
        int m = (l + r) / 2;
        sort(slots, l, m);
        sort(slots, m + 1, r);
        merge(slots, l, m, r);
    }
    return slots;
}
void makeslots(slot *slots, int n)
{
    slot *cur = sort(slots, 0, n - 1);
    // for (int i = 0; i < n; i++)
    //     printf("%d %d\n", slots[i].st, slots[i].end);
    int st = slots[0].st, end = slots[0].end;
    slot *madeslots = malloc(sizeof(slot) * n);
    int s = 0;
    for (int i = 1; i <= n; i++)
    {
        if (i == n)
        {
            madeslots[s].st = st;
            madeslots[s++].end = end;
            break;
        }
        else if (slots[i].st <= end)
        {
            if (slots[i].end > end)
            {
                end = slots[i].end;
                // printf("hi %d", slots[i].st);
            }
        }
        else
        {
            madeslots[s].st = st;
            madeslots[s++].end = end;

            if (i < n)
            {
                st = slots[i].st;
                end = slots[i].end;
            }
        }
    }
    printf("\n%d\n", s);
    for (int i = 0; i < s; i++)
    {
        printf("%d %d\n", madeslots[i].st, madeslots[i].end);
    }
}
int main()
{
    int n;
    scanf("%d", &n);
    slot *slots = malloc(sizeof(slot) * n);
    for (int i = 0; i < n; i++)
    {
        scanf("%d %d", &(slots[i].st), &(slots[i].end));
    }
    makeslots(slots, n);
    return 0;
}