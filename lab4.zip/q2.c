// #include <stdio.h>
// #include <stdlib.h>

// void merge(int *a, int l, int m, int r)
// {
//     int i = 0, j = 0, k = l;
//     int n1 = m - l + 1;
//     int n2 = r - m;
//     int *left, *right;

//     left = malloc(sizeof(int) * n1);
//     right = malloc(sizeof(int) * n2);

//     for (int i = 0; i < n1; i++)
//         left[i] = a[i + l];
//     for (int i = 0; i < n2; i++)
//         right[i] = a[i + m + 1];

//     while (i < n1 || j < n2)
//     {
//         if ((i < n1 && left[i] < right[j]) || j == n2)
//         {
//             a[k] = left[i];
//             i++;
//         }
//         else if ((j < n2) || i == n1)
//         {
//             a[k] = right[j];
//             j++;
//         }
//         k++;
//     }
//     free(left);
//     free(right);
// }
// void sort(int *a, int l, int r)
// {
//     if (l < r)
//     {
//         int m = (l + r) / 2;
//         sort(a, l, m);
//         sort(a, m + 1, r);
//         merge(a, l, m, r);
//     }
// }

// void dogowar(int *a, int n)
// {
//     sort(a, 0, n - 1);
//     int sn = 0, s;
//     for (int i = 0; i < n; i++)
//     {
//         printf("%d ", a[i]);
//     }
//     printf("\n");
//     for (int i = n - 1; i >= 0; i--)
//     {
//         printf("%d %d\n", a[i], n - i);
//         if (a[i] <= n - i)
//         {
//             printf("%d", a[i]);
//             break;
//         }
//         else
//         {
//             continue;
//         }
//     }
// }
// int main()
// {
//     int n;
//     scanf("%d", &n);
//     int *l = malloc(sizeof(int) * n);
//     for (int i = 0; i < n; i++)
//     {
//         scanf("%d", &l[i]);
//     }
//     dogowar(l, n);

//     return 0;
// }

#include <stdio.h>
#include <stdlib.h>

int isPoss(int *arr, int n, int x)
{

    int eq = 0, grt = 0, sml = 0;
    for (int i = 0; i < n; i++)
    {
        if (arr[i] == x)
            eq++;
        else if (arr[i] > x)
            grt++;
        else
            sml++;
    }
    // printf("%d %d %d\n",grt,eq,sml);
    if ((grt + eq >= x))
        return 1;
    return 0;
}

int Binary(int *arr, int n, int max)
{

    int l = 1, r = max;
    while (l <= r)
    {
        int mid = l + (r - l) / 2;

        if (isPoss(arr, n, mid) && !(isPoss(arr, n, mid + 1)))
            return mid;

        if (isPoss(arr, n, mid))
            l = mid + 1;
        else
            r = mid - 1;
    }
    return 0;
}

int main()
{

    int n, *arr, max;
    scanf("%d", &n);

    arr = malloc(n * sizeof(int));

    for (int i = 0; i < n; i++)
    {
        scanf("%d", &arr[i]);
    }

    max = arr[0];

    for (int i = 0; i < n; i++)
    {
        if (arr[i] > max)
            max = arr[i];
    }

    printf("%d\n", Binary(arr, n, max));
    // for (int i = 1; i <= max; i++)
    // {
    //     printf("%d - %d\n",i,isPoss(arr , n , i));
    // }

    // for (int i = max; i > 0; i--)
    // {
    //     if(isPoss(arr , n , i)){
    //     printf("%d",i);
    //     break;
    //     }
    // }

    return 0;
}