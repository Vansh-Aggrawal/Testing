#include <stdio.h>
#include <stdlib.h>

// void merge(int *a, int l, int m, int r)
// {
//     int i = 0, j = 0, k = l;

//     int n1 = m - l + 1;
//     int n2 = r - m;

//     int *left = malloc(sizeof(int) * n1);
//     int *right = malloc(sizeof(int) * n2);

//     for (int i = 0; i < n1; i++)
//         left[i] = a[l + i];
//     for (int j = 0; j < n1; j++)
//         right[j] = a[m + j + 1];

//     while (i < n1 || j < n2)
//     {
//         // printf("%d %d\n", i, j);
//         if (j == n2 || (i < n1 && left[i] < right[j]))
//         {
//             a[k] = left[i];
//             i++;
//         }
//         else if (j < n2 || i == n1)
//         {
//             a[k] = right[j];
//             j++;
//         }

//         k++;
//     }
//     free(left);
//     free(right);
// }
// void sort(int *a, int l, int r)
// {
//     if (l < r)
//     {
//         int m = (l + r) / 2;
//         sort(a, l, m);
//         sort(a, m + 1, r);
//         merge(a, l, m, r);
//     }
// }

void makepairs(int *a, int n)
{
    // sort(a, 0, n - 1);
    int *tz = calloc(n, sizeof(int));
    int max = 0;
    for (int i = 0; i < n; i++)
    {
        for (int j = 5; j <= a[i]; j = j * 5)
        {
            tz[i] = tz[i] + a[i] / j;
        }
        if (max < tz[i])
            max = tz[i];
    }
    int *c = calloc(max + 1, sizeof(int));
    for (int i = 0; i < n; i++)
    {
        c[tz[i]]++;
    }
    int ans = 0;
    for (int i = 0; i < max; i++)
    {
        ans = ans + (int)((c[i] - 1) * (c[i]) / 2);
    }
    printf("%d", ans);
}
int main()
{
    int n;
    scanf("%d", &n);
    int *l = malloc(sizeof(int) * n);
    for (int i = 0; i < n; i++)
        scanf("%d", &l[i]);

    makepairs(l, n);
    // for (int i = 0; i < n; i++)
    //     printf("%d ", l[i]);

    return 0;
}