#include <stdio.h>
#include <stdlib.h>
// #include <string.h>

int main()
{
    long n, m;
    scanf("%ld %ld", &n, &m);

    long max;
    max = (n - m + 1) * (n - m) / 2;

    long *l = calloc(m, sizeof(long));

    // memset(l, (int)m / n, sizeof(int) * m);

    for (int i = 0; i < n; i++)
    {
        l[i % m]++;
    }
    long min = 0;

    for (int i = 0; i < m; i++)
    {
        // printf("%d ", l[i]);
        min = min + (int)((l[i] * (l[i] - 1)) / 2);
    }
    printf("%ld ", min);

    printf("%ld", max);
    free(l);

    return 0;
}