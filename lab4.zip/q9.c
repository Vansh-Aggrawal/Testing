#include <stdio.h>
#include <stdlib.h>

int maximum(int *a, int n)
{
    int max = a[0];
    for (int i = 1; i < n; i++)
    {
        if (max < a[i])
            max = a[i];
    }
    return max;
}

int main()
{
    int n;
    scanf("%d", &n);
    int *a = malloc(sizeof(int) * n);

    for (int i = 0; i < n; i++)
        scanf("%d", &a[i]);

    int max = maximum(a, n);

    for (int i = max; i > 0; i--)
    {
        int rc = 1, flag = 1;
        for (int j = 0; j < n; j++)
        {
            if (a[j] % i != 0 && rc == 1)
            {
                rc--;
                // printf("%d %d\n", a[j], i);
            }
            else if (a[j] % i != 0 && rc == 0)
            {
                flag = 0;
                break;
            }
        }
        if (flag == 1)
        {
            printf("%d", i);
            break;
        }
    }
    // if (p==)
}