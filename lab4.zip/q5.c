#include <stdio.h>
#include <stdlib.h>
#include <math.h>
int gdiv(int a, int b)
{
    if (a == 0 || b == 0)
    {
        return 0;
    }
    if (b % a == 0 || a == b)
    {
        return a;
    }
    if (a > b)
    {
        return gdiv(a - b, b);
    }
    // printf("%d %d\n", a, b);
    return gdiv(a, b - a);
}

int main()
{
    long a, b, i, c = 0;
    scanf("%ld %ld", &a, &b);
    int *l = malloc(sizeof(long) * ((int)sqrt(a)));
    for (i = 1; i * i < a; i++)
    {
        if (a % i == 0)
        {
            l[c++] = i;
            l[c++] = a / i;
        }
    }
    // printf("%d %d ", i, c);
    if (a % (i) == 0)
    {
        l[c++] = i;
    }

    long ans = 1;

    for (long j = 0; j < c; j++)
    {
        // printf("%d ", l[j]);
        if (ans < l[j])
        {
            if (gdiv(l[j], b) == 1)
            {
                ans = l[j];
            }
        }
    }
    printf("%ld", ans);
    return 0;
}