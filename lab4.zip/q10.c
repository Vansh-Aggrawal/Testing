#include <stdio.h>
#include <stdlib.h>

int median(int *a, int n)
{
    int median;
    for (int i = 0; i < n - 1; i++)
    {
        for (int j = i; j < n - 1; j++)
        {
            if (a[j + 1] < a[j])
            {
                int t = a[j];
                a[j] = a[j + 1];
                a[j + 1] = a[j];
            }
        }
    }
    if (n % 2 == 0)
    {
        return ((a[n / 2 - 1] + a[n / 2]) / 2);
    }
    else
    {
        return a[n / 2];
    }
}
int main()
{
    int n;
    scanf("%d", &n);
    int *a = malloc(sizeof(int) * n);

    for (int i = 0; i < n; i++)
        scanf("%d", &a[i]);
    int avg = median

        (a, n);
    int ans = 0;
    for (int i = 0; i < n; i++)
    {
        if (avg > a[i])
        {
            ans = ans + avg - a[i];
        }
        else
        {
            ans = ans + a[i] - avg;
        }
    }
    printf("%d", ans);
    return 0;
}