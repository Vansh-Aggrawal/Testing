#include <stdio.h>
#include <stdlib.h>

void bon(int *a, int n, int k)
{
    int max = a[0];
    for (int i = 0; i < n; i++)
    {
        if (max < a[i])
            max = a[i];
    }

    // printf("%d", max);

    int *b = calloc(max + 1, sizeof(int));
    // int *c = calloc(max,sizeof(int));
    for (int i = 0; i < n; i++)
    {
        // c[a[i]] = a[i];
        // printf("%d ", a[i]);
        b[a[i]]++;
    }
    printf("\n");
    for (int i = 0; i < k; i++)
    {
        int m = b[0], ind = 0;
        for (int j = 0; j < max + 1; j++)
        {
            // printf("%d ", b[j]);
            if (m < b[j])
            {
                m = b[j];
                ind = j;
                // printf("%d ", ind);
            }
        }
        // printf("\n");
        printf("%d ", ind);
        b[ind] = 0;
    }
    free(b);
}
int main()
{
    int n, k;
    scanf("%d %d", &n, &k);
    int *l = malloc(sizeof(int) * n);
    for (int i = 0; i < n; i++)
    {
        scanf("%d", &l[i]);
    }
    bon(l, n, k);
    free(l);
    return 0;
}