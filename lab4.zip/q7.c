#include <stdio.h>
#include <stdlib.h>

int getmax(int *a, int n)
{
    int m = a[0];
    for (int i = 0; i < n; i++)
        if (m < a[i])
            m = a[i];
    return m;
}
void sort(int *a, int n, int p)
{
    int *o = malloc(sizeof(int) * (n + 1));
    int count[10] = {0};

    for (int i = 0; i < n; i++)
        count[(a[i] / p) % 10]++;

    for (int i = 1; i < 10; i++)
    {
        count[i] = count[i - 1] + count[i];
    }

    for (int i = n - 1; i >= 0; i--)
    {
        o[count[(a[i] / p) % 10] - 1] = a[i];
        count[(a[i] / p) % 10]--;
    }

    for (int i = 0; i < n; i++)
    {
        a[i] = o[i];
    }
    free(o);
}
void printlist(int *a, int n)
{
    for (int i = 0; i < n; i++)
        printf("%d ", a[i]);
    printf("\n");
}
void radixsort(int n, int *a)
{
    int max = getmax(a, n);
    for (int i = 1; max / i > 0; i = i * 10)
    {
        sort(a, n, i);
        printlist(a, n);
    }
}
int main()
{
    int n;
    scanf("%d", &n);

    int *a = malloc(sizeof(int) * n);

    for (int i = 0; i < n; i++)
        scanf("%d", &a[i]);

    radixsort(n, a);

    return 0;
}