#include <stdio.h>
#include <stdlib.h>

struct node
{
    int data;
    struct node *next;
    struct node *prev;
};

typedef struct node Node;

Node *createNode(int val)
{
    Node *n = malloc(sizeof(Node));
    n->data = val;
    n->next = NULL;
    n->prev = NULL;
    return n;
}
Node *addToList(Node *head, int val)
{
    Node *n = createNode(val);
    if (head == NULL)
    {
        return n;
    }
    Node *cur = head;
    while (cur->next != NULL)
    {
        cur = cur->next;
    }
    cur->next = n;
    n->prev = cur;
    return head;
}
void printList(Node *head)
{
    Node *cur = head;
    while (cur != NULL)
    {
        printf("%d ", cur->data);
        cur = cur->next;
    }
    printf("\n");
}
Node *takelist(int n)
{

    // scanf("%d", k);
    Node *head = NULL;
    // printf("hi");
    for (int i = 0; i < n; i++)
    {
        int val;
        scanf("%d", &val);
        head = addToList(head, val);
    }
    return head;
}
Node *rotate(Node *head, int k)
{
    Node *cur = head;
    int n = 0;
    while (cur->next != NULL)
    {
        cur = cur->next;
        n++;
    }
    cur->next = head;
    head->prev = cur;
    cur = head;
    for (int i = 0; i < n - k % (n + 1) + 1; i++)
    {
        cur = cur->next;
    }
    cur->prev->next = NULL;
    cur->prev = NULL;
    return cur;
}
int main()
{
    int n, k;
    scanf("%d %d", &n, &k);
    Node *head = takelist(n);
    Node *rothead = rotate(head, k);
    printList(rothead);
    return 0;
}