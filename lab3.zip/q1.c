#include <stdio.h>
#include <stdlib.h>

struct node
{
    int data;
    struct node *next;
    struct node *prev;
};

typedef struct node Node;

Node *createNode(int val)
{
    Node *n = malloc(sizeof(Node));
    n->data = val;
    n->next = NULL;
    n->prev = NULL;
    return n;
}
Node *addToList(Node *head, int val)
{
    Node *n = createNode(val);
    if (head == NULL)
    {
        return n;
    }
    Node *cur = head;
    while (cur->next != NULL)
    {
        cur = cur->next;
    }
    cur->next = n;
    n->prev = cur;
    return head;
}
void printList(Node *head)
{
    Node *cur = head;
    while (cur != NULL)
    {
        printf("%d ", cur->data);
        cur = cur->next;
    }
    printf("\n");
}
Node *takelist()
{
    int n;
    scanf("%d", &n);
    Node *head = NULL;
    for (int i = 0; i < n; i++)
    {
        int val;
        scanf("%d", &val);
        head = addToList(head, val);
    }
    return head;
}
Node *returncur(Node *head)
{
    return head;
}
int findlen(Node *head)
{
    Node *cur = head;
    int i = 0;
    while (cur != NULL)
    {
        i++;
        cur = cur->next;
    }
    return i;
}
Node *getoperation(Node *head, int c, int *play)
{
    if (c == 1)
    {
        int val;
        scanf("%d", &val);
        head = addToList(head, val);
    }
    else if (c == 2)
    {
        Node *cur = head;
        int i = 0;
        while (cur != NULL && i < *play)
        {
            i++;
            cur = cur->next;
        }
        printf("%d\n", cur->data);
    }
    else if (c == 3)
    {
        int n = findlen(head);
        if (*play < n)
        {
            (*play)++;
        }
    }
    else if (c == 4)
    {
        if (*play > 0)
        {
            (*play)--;
        }
    }
    else if (c != 5)
    {
        printf("INVALID CHOICE");
    }
    return head;
}
int main()
{
    int n = 0;
    int c = 0;
    Node *head = takelist();
    while (c != 5)
    {
        scanf("%d", &c);
        head = getoperation(head, c, &n);
    }
    return 0;
}