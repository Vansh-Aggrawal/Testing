#include <stdio.h>
#include <stdlib.h>

int valid(int n, int k, int *a, int s)
{
    int c = 0;
    if (s == 0)
        return 1;
    for (int i = 0; i < n; i++)
    {
        c = c + a[i] / s;
    }
    if (c >= k)
        return 1;
    return 0;
}
int main()
{
    int n, k;
    scanf("%d %d", &n, &k);

    int *a = malloc(sizeof(int) * n);

    for (int i = 0; i < n; i++)
        scanf("%d", &a[i]);

    int max = 0;
    for (int i = 0; i < n; i++)
    {
        if (max < a[i])
            max = a[i];
    }
    int l = 0, r = max;
    int mid = (l + r) / 2;
    int ans = 0;
    while (l <= r)
    {
        int v = valid(n, k, a, mid);
        if (l == r)
        {
            if (v == 1)
                ans = mid;
            l++;
        }
        else if (v == 0)
        {
            r = mid - 1;
            mid = (l + r) / 2;
        }
        else if (v == 1)
        {
            ans = mid;
            l = mid + 1;
            mid = (l + r) / 2;
        }
    }
    printf("%d", ans);

    free(a);

    return 0;
}