#include <stdio.h>
#include <stdlib.h>

int main()
{
    unsigned long long n;
    scanf("%lld", &n);
    // printf("%lld\n", n);
    unsigned long long l = 0, r = n - 1, ans = 0;
    unsigned long long mid = (l + r) / 2;
    // printf("%ld", mid);

    while (l <= r)
    {
        if (mid == n / mid || l == r)
        {
            // printf("hi");
            ans = mid;
            break;
        }
        else if (mid > n / mid)
        {
            r = mid - 1;
            mid = (l + r) / 2;
            // printf("%d %d %d+\n", l, r, i);
            if (mid > n / mid && (mid - 1) < n / (mid - 1))
            {
                // printf("hi");

                ans = mid;
                break;
            }
        }
        else if (mid < n / mid)
        {
            l = mid + 1;
            mid = (l + r) / 2;
            // printf("%d %d %d-\n", l, r, i);
            if ((mid + 1) > n / (mid + 1) && mid < n / mid)
            {
                // printf("hi1\n");
                ans = mid;
                break;
            }
        }
    }
    if (ans <= n / mid)
        printf("%lld", ans);
    else
        printf("%lld", ans - 1);
    return 0;
}