#include <stdio.h>
#include <stdlib.h>

int main()
{
    int n, k = 0;
    scanf("%d", &n);
    int *a = malloc(sizeof(int) * (n + 1));
    for (int i = 0; i < n; i++)
    {
        scanf("%d", &a[i]);
    }
    int l = 0, r = n - 1;
    int mid = (l + r) / 2;
    int x = a[0];
    while (l < n)
    {
        while (l <= r)
        {
            // printf("%d %d")
            if (a[mid] == x && a[mid + 1] != x)
            {
                k++;
                l = mid + 1;
                r = n - 1;
                mid = (l + r) / 2;
                // printf("%d", x);
                break;
            }
            else if (a[mid] > x)
            {
                r = mid - 1;
                mid = (l + r) / 2;
            }
            else if (a[mid] <= x)
            {
                l = mid + 1;
                mid = (l + r) / 2;
            }
            else if (l == r)
            {
                k++;
                l = mid + 1;
                r = n - 1;
                // printf("%d %d", x, mid);
                mid = (l + r) / 2;
                break;
            }
        }
        x = a[l];
    }

    printf("%d", k);
    return 0;
}