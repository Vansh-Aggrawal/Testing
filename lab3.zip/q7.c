#include <stdio.h>
#include <stdlib.h>

int main()
{
    int n, m;
    scanf("%d %d", &n, &m);
    int *a = malloc(sizeof(int) * n + 1);

    for (int i = 0; i < n; i++)
    {
        scanf("%d", &a[i]);
    }
    int l = 0, r = n - 1;
    int f = 0;
    int ans;
    int mid;
    while (l <= r && f == 0)
    {
        mid = (int)(l + r) / 2;
        if ((a[mid] < m && a[mid + 1] > m) || (a[mid] == m) || (mid == 0 && a[mid] > m) || l == r)
        {
            if (mid == 0 && a[mid] > m)
            {
                ans = -1;
                break;
            }

            f = 1;
            ans = a[mid];
            break;
        }
        else if (a[mid] < m)
        {
            l = mid + 1;
            mid = (int)(l + r) / 2;
        }
        else if (a[mid] > m)
        {
            r = mid - 1;
            // printf("%d", i);
            mid = (l + r) / 2;
        }
    }
    printf("%d", ans);
    return 0;
}