#include <stdio.h>
#include <stdlib.h>

int main()
{
    int n;
    scanf("%d", &n);

    int x = n * (n - 1) / 4;

    int l = 0, r = n, ans = 0;
    int mid = (l + r) / 2;

    int ix;
    while (l <= r)
    {
        ix = mid * (mid - 1) / 2;
        if (x >= ix && x < (mid + 1) * mid / 2)
        {
            ans = mid;
            break;
        }
        else if (x > ix)
        {
            l = mid;
            mid = (l + r) / 2;
            // printf("%d %d %d+\n", l, r, i);
            // if (x > ix && !(x > (ix - mid+ 1)))
            // {
            //     ans = mid;
            //     break;
            // }
        }
        else if (x < ix)
        {
            r = mid;
            mid = (l + r) / 2;
            // printf("%d %d %d-\n", l, r, i);

            // if (x < ix && !(x < (ix - mid+ 1)))
            // {
            //     ans = mid;
            //     break;
            // }
        }
    }
    printf("%d", n - ans);
    return 0;
}