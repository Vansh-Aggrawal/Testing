#include <stdio.h>
#include <stdlib.h>

struct node
{
    int data;
    struct node *next;
    struct node *prev;
};

typedef struct node Node;

Node *createNode(int val)
{
    Node *n = malloc(sizeof(Node));
    n->data = val;
    n->next = NULL;
    n->prev = NULL;
    return n;
}
Node *addToList(Node *head, int val)
{
    Node *n = createNode(val);
    if (head == NULL)
    {
        return n;
    }
    Node *cur = head;
    while (cur->next != NULL)
    {
        cur = cur->next;
    }
    cur->next = n;
    n->prev = cur;
    return head;
}
void printList(Node *head)
{
    Node *cur = head;
    while (cur != NULL)
    {
        printf("%d ", cur->data);
        cur = cur->next;
    }
    printf("\n");
}
Node *takelist()
{
    int n;

    scanf("%d", &n);
    // scanf("%d", k);
    Node *head = NULL;
    // printf("hi");
    for (int i = 0; i < n; i++)
    {
        int val;
        scanf("%d", &val);
        head = addToList(head, val);
    }
    return head;
}
void maketeam(Node *head)
{
    Node *l = head;
    Node *r = head;
    Node *last;
    int n;
    if (head != NULL)
    {
        n = 1;
    }
    else
    {
        n = 0;
    }
    while (r->next != NULL)
    {
        r = r->next;
        n++;
    }
    last = r;
    int ll = 1, rl = 1, ls = l->data, rs = r->data;
    int bl = 0, br = 0;
    // int f = 0;
    while (l != r && ll + rl <= n)
    {
        // printf("%d %d\n", ll, rl);
        if (ls == rs)
        {
            // f = 1;
            bl = ll;
            br = rl;
            r = r->prev;
            rs = rs + r->data;
            // printf("%d %d\n", bl, br);
            l = l->next;
            ls = ls + l->data;
            rl++;
            ll++;
            // printf("%d %d\n", bl, br);
            // printf(">%d %d<\n", l->data, r->data);
        }
        else if (ls > rs)
        {
            r = r->prev;
            rs = rs + r->data;
            // printf("%d %d\n", ll, rl);
            rl++;
        }
        else if (ls < rs)
        {
            l = l->next;
            ls = ls + l->data;
            ll++;
            // printf("%d %d\n", ll, rl);
        }
    }

    printf("%d %d", bl, br);
}
int main()
{
    Node *head = takelist();
    maketeam(head);
    return 0;
}