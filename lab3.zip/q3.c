#include <stdio.h>
#include <stdlib.h>

struct node
{
    int data;
    struct node *next;
    struct node *prev;
};

typedef struct node Node;

Node *createNode(int val)
{
    Node *n = malloc(sizeof(Node));
    n->data = val;
    n->next = NULL;
    n->prev = NULL;
    return n;
}
Node *addToList(Node *head, int val)
{
    Node *n = createNode(val);
    if (head == NULL)
    {
        return n;
    }
    Node *cur = head;
    while (cur->next != NULL)
    {
        cur = cur->next;
    }
    cur->next = n;
    n->prev = cur;
    return head;
}
void printList(Node *head)
{
    Node *cur = head;
    while (cur != NULL)
    {
        printf("%d ", cur->data);
        cur = cur->next;
    }
    printf("\n");
}
Node *takelist()
{
    int n;
    scanf("%d", &n);
    // scanf("%d", k);
    Node *head = NULL;
    for (int i = 0; i < n; i++)
    {
        int val;
        scanf("%d", &val);
        head = addToList(head, val);
    }
    return head;
}
int findlen(Node *head)
{
    Node *cur = head;
    int i = 0;
    while (cur != NULL)
    {
        i++;
        cur = cur->next;
    }
    return i;
}
int issum(Node *head, int s)
{
    Node *l = head;
    Node *r = head;
    while (r->next != NULL)
        r = r->next;
    while (l != r)
    {
        if ((l->data + r->data) == s)
        {
            // printf("1");
            return 1;
        }
        else if ((l->data + r->data) > s)
        {
            r = r->prev;
        }
        else if ((l->data + r->data) < s)
        {
            l = l->next;
        }
    }
    // printf("0");
    return 0;
}
int main()
{
    int s;
    scanf("%d", &s);
    Node *head = takelist();
    printf("%d", issum(head, s));
    return 0;
}